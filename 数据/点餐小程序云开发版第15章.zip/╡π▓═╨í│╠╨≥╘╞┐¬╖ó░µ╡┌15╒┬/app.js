//app.js
App({
  globalData: {
    zhuohao: null
  },
  onLaunch: function () {
    wx.cloud.init({
      env: 'xiaoshitou-0go20a09a67fc864'
    })
  }
})