Page({
  data: {
    userInfo: ''
  },
  onLoad() {
    let user = wx.getStorageSync('user')
    console.log('进入小程序的index页面获取缓存', user)
    this.setData({
      userInfo: user
    })
  },
  // 授权登录
  login() {
    wx.getUserProfile({
      desc: '必须授权才可以继续使用',
      success: res => {
        let user = res.userInfo
        // 把用户信息缓存到本地
        wx.setStorageSync('user', user)
        console.log("用户信息", user)
        this.setData({
          userInfo: user
        })
      },
      fail: res => {
        console.log('授权失败', res)
      }
    })
  },
  // 退出登录
  loginOut() {
    this.setData({
      userInfo: ''
    })
    wx.setStorageSync('user', null)
  },
  // 去我的订单页
  goMyorder() {
    wx.navigateTo({
      url: '/pages/myOrder/myOrder',
    })
  },
  // 去我的评价页
  goMycomment() {
    wx.navigateTo({
      url: '/pages/mycomment/mycomment',
    })
  },
  // 去管理员页
  goAdmin() {
    wx.navigateTo({
      url: '/pages/admin/admin',
    })
  },
  // 我的排号
  goPaihao() {
    wx.navigateTo({
      url: '/pages/paihao/paihao',
    })
  }
})