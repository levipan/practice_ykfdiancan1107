Page({
  data: {
    name: '',
    password: '',
    noLogin: true
  },
  onLoad() {
    let admin = wx.getStorageSync('admin')
    console.log('缓存登陆信息', admin)
    if (admin && admin.name && admin.password) {
      this.loginData(admin.name, admin.password)
    }
  },
  // 获取用户输入的账号
  getName(e) {
    this.setData({
      name: e.detail.value
    })
  },
  // 获取用户输入的密码
  getPassword(e) {
    this.setData({
      password: e.detail.value
    })
  },
  // 点击了登陆按钮
  goLogin() {
    let name = this.data.name
    let password = this.data.password
    if (!name) {
      wx.showToast({
        icon: "error",
        title: '请输入账号',
      })
      return
    }
    if (!password) {
      wx.showToast({
        icon: "error",
        title: '请输入密码',
      })
      return
    }
    console.log(name)
    console.log(password)
    this.loginData(name, password)
  },
  // 执行登陆的方法
  loginData(name, password) {
    wx.cloud.database().collection("admin")
      .where({
        name,
        password: password
      }).get().then(res => {
        console.log('返回的数据', res)
        if (res.data && res.data.length > 0) {
          // 登陆成功
          // 1，切换到登陆成功的页面
          this.setData({
            noLogin: false
          })
          let admin = {}
          admin.name = name
          admin.password = password
          // 2，缓存账号密码用于记录登陆状态
          wx.setStorageSync('admin', admin)
        } else {
          wx.showToast({
            icon: "error",
            title: '账号或密码错误',
          })
          wx.setStorageSync('admin', null)
        }
      }).catch(res => {
        console.log('请求失败', res)
      })
  },
  // 退出登陆
  loginout() {
    this.setData({
      noLogin: true
    })
    wx.setStorageSync('admin', null)
  },
  // 去后厨管理页
  goHouchu() {
    wx.navigateTo({
      url: '/pages/adminHouchu/adminHouchu',
    })
  },
  // 去管理员排号页
  goPaihao() {
    wx.navigateTo({
      url: '/pages/adminPaihao/adminPaihao',
    })
  }
})