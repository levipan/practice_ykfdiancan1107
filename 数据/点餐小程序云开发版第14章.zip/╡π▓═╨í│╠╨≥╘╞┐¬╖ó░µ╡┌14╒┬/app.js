//app.js
App({
  onLaunch: function () {
    wx.cloud.init({
      env: 'xiaoshitou-0go20a09a67fc864'
    })
  }
})