//app.js
App({
  onLaunch: function () {
    wx.cloud.init({
      env: 'mall-5g0n3fosa2834d2e'
    })
  }
})