//app.js
App({
  onLaunch: function () {
    wx.cloud.init({
      env: 'demo-7gw2zmftf30332d0'
    })
  }
})