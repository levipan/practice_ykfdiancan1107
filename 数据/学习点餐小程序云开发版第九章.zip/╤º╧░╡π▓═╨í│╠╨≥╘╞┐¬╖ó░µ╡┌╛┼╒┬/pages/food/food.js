const db = wx.cloud.database()
Page({
  onLoad: function (options) {
    console.log("options", options)
    let searchKey = options.searchKey
    db.collection('food').where({
        name: db.RegExp({
          regexp: searchKey,
          options: 'i' //不区分大小写
        })
      }).get()
      .then(res => {
        console.log('搜索成功', res)
      })
      .catch(res => {
        console.log('搜索失败', res)
      })
  },
})