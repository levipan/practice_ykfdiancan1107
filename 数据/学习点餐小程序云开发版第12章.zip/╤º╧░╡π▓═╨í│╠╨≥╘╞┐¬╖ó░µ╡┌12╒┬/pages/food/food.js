const db = wx.cloud.database()
let searchKey = ''
Page({
  onLoad: function (options) {
    console.log("options", options)
    searchKey = options.searchKey
    this.setData({
      key: searchKey
    })
    this.getSearchData()
  },
  //获取用户输入的内容
  getSearch(e) {
    // console.log(e.detail.value)
    searchKey = e.detail.value
  },
  //触发搜索事件
  goSearch() {
    console.log('触发了搜索', searchKey)
    if (searchKey && searchKey.length > 0) {
      this.getSearchData()
    } else {
      wx.showToast({
        icon: 'none',
        title: '搜索词为空',
      })
    }
  },
  // 获取搜索数据
  getSearchData() {
    db.collection('food').where({
        name: db.RegExp({
          regexp: searchKey,
          options: 'i' //不区分大小写
        })
      }).get()
      .then(res => {
        console.log('搜索成功', res)
        let list = res.data
        if (list && list.length > 0) {
          list.forEach(item => {
            item.num = 0
          })
          this.setData({
            foodList: list
          })
        }

      })
      .catch(res => {
        console.log('搜索失败', res)
      })
  },
  // 点击减少
  jian(e) {
    let id = e.currentTarget.dataset.id
    console.log('点击了-', e.currentTarget.dataset.id)
    let list = this.data.foodList
    list.forEach(item => {
      if (item._id == id) {
        if (item.num > 0) {
          item.num -= 1
        } else {
          wx.showToast({
            icon: 'none',
            title: '数量不能小于0',
          })
        }
      }
    })
    console.log('遍历以后的菜品列表', list)
    this.setData({
      foodList: list
    })
  },
  // 点击加号
  jia(e) {
    let id = e.currentTarget.dataset.id
    console.log('点击了+', e.currentTarget.dataset.id)
    let list = this.data.foodList
    console.log('当前菜品列表', list)
    list.forEach(item => {
      if (item._id == id) {
        item.num += 1
        // item.num = item.num + 1
      }
    })
    console.log('遍历以后的菜品列表', list)
    this.setData({
      foodList: list
    })

  }
})